function calculatelove() {

    var yourName = document.getElementById("yourName").value;
    var partnerName = document.getElementById("partnerName").value;
    var lovePercentage = Match.floor(Math.random() * 101);
    var resultElement = document.getElementById("result");

    resultElement.innerHTML = '${yourName} and ${partnerName}';
}